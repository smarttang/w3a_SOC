package log_send;

use IO::Socket;
use File::Tail;

sub new{
  $self={};
  $self->{connect_socket};
  $self->{send_socket};
  $self->{close_socket};
  bless $self;
  return $self;
}

# 与目标SOCKET建立连接
sub connect_socket{
  my $self=shift;
  if(@_){
     $self->{'connect_socket'}=IO::Socket::INET->new(PeerAddr => @_[0],PeerPort => @_[1],Proto =>'tcp') or die $@;

  }
  return $self->{'connect_socket'};
}

# 发送数据
sub send_socket{
  my $self=shift;
  if(@_){
     my $sock=@_[0];
     my $send=@_[1];
     print $sock $send . "\n";
  }
}

# 关闭SOCKET连接
sub close_socket{
  my $self=shift;
  if(@_){
    $self->{'close_socket'}=@_[0]->close or die $!;
    exit 1;
  }
  return $self->{'close_socket'};
}


1;
