package log_grep;

sub new{
  $self={};
  $self->{date_grep}=undef;
  $self->{default_grep}=undef;
  bless $self;
  return $self;
}

# 日期过滤策略
sub date_grep{
  my $self=shift;
  if(@_){
    @_[0]=~m#\[(.*)\]#;
    $1=~m#(.*)\s#;
    $date=$1;
    $date=~s#:# #;
    return split(/\s/,$date);
  }
}

# 默认过滤策略
sub default_grep{
  my $self=shift;
  if(@_){
    return split(/\s/,@_[0]);
  }
}

1;
