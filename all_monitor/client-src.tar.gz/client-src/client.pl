#!/usr/bin/perl

use log_grep;
use log_send;
use Config::Abstract::Ini;
$regex_nginx=qr/^([0-9.]+)\s([\w.-]+)\s([\w.-]+)\s(\[[^\[\]]+\])\s"((?:[^"]|\")+)"\s(\d{3})\s(\d+|-)\s"((?:[^"]|\")+)"\s"((?:[^"]|\")+)"$/o;
$regex_apache=qr/^([0-9.]+)\s([\w.-]+)\s([\w.-]+)\s(\[[^\[\]]+\])\s"((?:[^"]|\")+)"\s(\d{3})\s(\d+|-)\s"((?:[^"]|\")+)"\s"((?:[^"]|\")+)"$/o;
eval{
	eval{
		my $cfg=new Config::Abstract::Ini("config.ini");
		%Data=$cfg->get_entry('remove');
	};
	if($@){
		print "------------------------\n";
		print "config.ini 配置文件缺失!\n";
		print "config.ini  not  here  !\n";
		print "------------------------\n";
		exit;
	}
	$_tmp=$Data{'log_type'};
	print "server_type:$_tmp\n";
	if($_tmp eq "Apache"){
		$sock=log_send->new();
		$key=$sock->connect_socket($Data{'remove-ip'},$Data{'port'});
		$file=File::Tail->new($Data{'log_path'});
		while(defined($_=$file->read)){
		  ~m/$regex_apache/;
		  $log_grep=log_grep->new();
		  @date=$log_grep->date_grep($4);
		  @action=$log_grep->default_grep($5);
		  @client=$log_grep->default_grep($9);
		  $base="t:$Data{'log_type'}|me:$action[1]|so:$1|lo:$Data{'local-ip'}|da:$date[0]|ti:$date[1]|opt:$action[0]|of:$6|u:$Data{'user'}\n";
		  print $base;
		  $sock->send_socket($key,$base);
		}
		$sock->close_socket($key);
		close IN;
	}elsif($_tmp eq "Nginx"){
                $sock=log_send->new();
                $key=$sock->connect_socket($Data{'remove-ip'},$Data{'port'});
                $file=File::Tail->new($Data{'log_path'});
                while(defined($_=$file->read)){
                  ~m/$regex_nginx/;
                  $log_grep=log_grep->new();
                  @date=$log_grep->date_grep($4);
                  @action=$log_grep->default_grep($5);
                  @client=$log_grep->default_grep($9);
                  $base="t:$Data{'log_type'}|me:$action[1]|so:$1|lo:$Data{'local-ip'}|da:$date[0]|ti:$date[1]|opt:$action[0]|of:$6|u:$Data{'user'}\n";
                  $sock->send_socket($key,$base);
                }
                $sock->close_socket($key);
                close IN;
	}
};
if($@)
{
  print "----------------------\n";
  print "连接异常,请联系提供商!\n";
  print "connect Socket error! \n";
  print "----------------------\n";
}
